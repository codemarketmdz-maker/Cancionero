# Cancionero de Misa (app Android)

Escucha el micrófono, reconoce las palabras que se cantan, busca la canción en tu cancionero y va marcando el renglón que se está cantando.

## Cómo conseguir el APK (GitHub lo compila por vos)

1. Creá un repositorio nuevo en GitHub (por ejemplo `cancionero-misa`).
2. Subí **todo el contenido de esta carpeta** (incluida la carpeta oculta `.github`).
3. Entrá a la pestaña **Actions**. La compilación arranca sola con cada subida (también podés tocar *Compilar APK → Run workflow*). Tarda unos 3–5 minutos.
4. Cuando termine, andá a **Releases → "APK actual"** y bajá `cancionero-misa.apk` desde el celular. También queda como artefacto dentro de la corrida de Actions.
5. Abrí el APK en el celular e instalalo (Android te va a pedir permitir "instalar apps de orígenes desconocidos").

## Cargar las canciones

Las letras **no vienen incluidas**: muchas canciones litúrgicas tienen derechos de autor, así que las cargás vos desde tu cancionero.

- **Desde la app:** botón **+ Agregar canción**, escribís el título, pegás la letra (un renglón por línea, línea en blanco entre estrofas) y guardás. Quedan guardadas en el celular.
- **Desde el código:** editá `app/src/main/assets/canciones.json` con el formato del ejemplo y subí el cambio; GitHub genera un APK nuevo con esas canciones adentro.

## Cómo se usa

1. Tocá **Escuchar y buscar canción** (la primera vez acepta el permiso del micrófono).
2. Cantá o acercá el celular a quien canta. Cuando reconoce la canción, abre la letra y resalta el renglón actual.
3. Si se pierde, tocá el renglón correcto y sigue desde ahí.

## Límites a tener en cuenta

- El reconocimiento de voz de Android funciona con internet en la mayoría de los celulares.
- Con mucha gente cantando y música de fondo, el reconocimiento falla más; conviene probarlo en una misa real.
- Algunos celulares hacen un "bip" cada vez que reinician la escucha.
- El APK es de prueba (firmado en modo debug): sirve para instalar en tus celulares, no para publicar en Play Store.
