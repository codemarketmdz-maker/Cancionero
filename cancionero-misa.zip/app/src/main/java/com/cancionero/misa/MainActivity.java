package com.cancionero.misa;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final int REQ_MIC = 1;
    private static final int REQ_FILE = 2;

    private WebView web;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private ValueCallback<Uri[]> filePathCallback;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir el enlace", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && filePathCallback != null) {
            filePathCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCallback = null;
        }
    }

    // ---------- Puente JS <-> Java ----------

    private class Bridge {
        @JavascriptInterface
        public String getSongs() {
            try (InputStream in = getAssets().open("canciones.json")) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString("UTF-8");
            } catch (Exception e) {
                return "{\"canciones\":[]}";
            }
        }

        @JavascriptInterface
        public void start() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                } else {
                    begin();
                }
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(MainActivity.this::end);
        }

        @JavascriptInterface
        public void copy(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("texto", text));
                    Toast.makeText(MainActivity.this, "Copiado", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void js(String code) {
        web.evaluateJavascript(code, null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MIC) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                begin();
            } else {
                js("onStatus('Falta el permiso del micrófono')");
            }
        }
    }

    // ---------- Reconocimiento de voz ----------

    private void begin() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onStatus('Este celular no tiene reconocimiento de voz disponible')");
            return;
        }
        listening = true;
        js("onListening(true)");
        startRec();
    }

    private void startRec() {
        if (!listening) return;
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L);
        try {
            recognizer.startListening(i);
        } catch (Exception e) {
            destroyRecognizer();
            restart(800);
        }
    }

    private void restart(long delayMs) {
        main.postDelayed(() -> {
            if (listening) startRec();
        }, delayMs);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
    }

    private void end() {
        listening = false;
        main.removeCallbacksAndMessages(null);
        destroyRecognizer();
        js("onListening(false)");
    }

    private void sendResults(Bundle b, boolean fin) {
        if (b == null) return;
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r != null && !r.isEmpty() && r.get(0) != null && !r.get(0).isEmpty()) {
            js("onHeard(" + JSONObject.quote(r.get(0)) + "," + fin + ")");
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onPartialResults(Bundle partialResults) {
            sendResults(partialResults, false);
        }

        @Override
        public void onResults(Bundle results) {
            sendResults(results, true);
            restart(250);
        }

        @Override
        public void onError(int error) {
            if (!listening) return;
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                end();
                js("onStatus('Falta el permiso del micrófono')");
            } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                destroyRecognizer();
                restart(700);
            } else if (error == SpeechRecognizer.ERROR_NETWORK
                    || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                    || error == SpeechRecognizer.ERROR_SERVER) {
                js("onStatus('Sin internet: el reconocimiento de voz lo necesita en la mayoría de los celulares')");
                restart(1500);
            } else {
                // No se entendió nada, silencio, etc.: seguimos escuchando
                restart(300);
            }
        }
    };

    // ---------- Ciclo de vida ----------

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.handleBack ? window.handleBack() : false)", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (listening) end();
    }

    @Override
    protected void onDestroy() {
        listening = false;
        main.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
